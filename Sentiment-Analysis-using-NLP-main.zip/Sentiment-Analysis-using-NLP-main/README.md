# Sentiment-Analysis-using-NLP
This project implements a sentiment analysis model using Natural Language Processing (NLP) techniques. The model is designed to determine the sentiment of a given statement — whether it is positive or negative. It uses a Logistic Regression algorithm.

Steps to use

1 Download the folder
2 Install all required libraries 
3 open command promt and give the command //"cd" file path of the downloaded folder//
4 Now use the command "python app.py"
5 click on the local host web address


Contributers
1 Harsh Tanpure
2 Arpit Thakur
3 Shivraj Sagane
4 Yuvraj Mahale
5 Yash Gorale
6 Himanshu Shelke
